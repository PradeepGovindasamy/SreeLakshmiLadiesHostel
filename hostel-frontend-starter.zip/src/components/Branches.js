import React, { useEffect, useState } from 'react';
import api from '../api/axios';

function Branches() {
  const [branches, setBranches] = useState([]);

  useEffect(() => {
    api.get('branches/')
      .then(res => setBranches(res.data))
      .catch(err => console.error(err));
  }, []);

  return (
    <div>
      <h2>Branches</h2>
      <ul>
        {branches.map(branch => (
          <li key={branch.id}>{branch.name} - {branch.address}</li>
        ))}
      </ul>
    </div>
  );
}

export default Branches;