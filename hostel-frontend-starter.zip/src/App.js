import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import LoginForm from './components/LoginForm';
import Branches from './components/Branches';

function App() {
  const isAuthenticated = !!localStorage.getItem('access');
  return (
    <Router>
      <Routes>
        <Route path="/" element={<LoginForm />} />
        {isAuthenticated && <Route path="/branches" element={<Branches />} />}
      </Routes>
    </Router>
  );
}

export default App;